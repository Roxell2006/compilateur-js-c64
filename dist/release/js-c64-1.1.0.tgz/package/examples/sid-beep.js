import { c64 } from "./c64.js";

c64.clearScreen();
c64.printAt(0, 0, "SID V0.6.0");
c64.printAt(0, 2, "3 VOIX");

c64.sid.volume(15);

c64.sid.voice(1).waveform("pulse");
c64.sid.voice(1).pulseWidth(0x0800);
c64.sid.voice(1).attackDecay(0x11);
c64.sid.voice(1).sustainRelease(0xf0);

c64.sid.voice(2).waveform("triangle");
c64.sid.voice(2).attackDecay(0x11);
c64.sid.voice(2).sustainRelease(0xd0);

c64.sid.voice(3).waveform("saw");
c64.sid.voice(3).attackDecay(0x11);
c64.sid.voice(3).sustainRelease(0xa0);

c64.sid.playSong({
  tempo: 24,
  voices: [
    ["C4", "E4", "G4", "C5", "G4", "E4", "C4", "R"],
    [
      { note: "C3", duration: 2 },
      { note: "G2", duration: 2 },
      { note: "E2", duration: 2 },
      { note: "C2", duration: 2 }
    ],
    [
      { note: "C5", duration: 1 },
      { note: "R", duration: 1 },
      { note: "E5", duration: 1 },
      { note: "R", duration: 1 },
      { note: "G5", duration: 1 },
      { note: "R", duration: 1 },
      { note: "E5", duration: 1 },
      { note: "R", duration: 1 }
    ]
  ]
});

