# Changelog

## 1.1.0

- Prepared npm metadata, documentation and the project starter for 1.1.0
- Strengthened package-content checks and installation validation, including the JavaScript source programs and reference examples

- Optimized natural-mode private temporaries and expression copies, with separate routine/IRQ storage and conservative lifetime checks
- Recognized full typed-array fill loops without changing side effects, counter wrapping or IRQ-observable write ordering; added optimization reports and a compiler API comparison switch
- Reduced natural Tetris from 104 to 64 scalar RAM bytes and from 3,906 to 3,768 PRG bytes without changing its source; added reproducible measurements and differential 6502 tests

- Added complete natural-mode Tetris, Platformer and interactive hires reference programs, with executed-6502 gameplay checks and PAL raster parity for both Platformer versions
- Kept deferred scroll scheduling when camera follow is called inside named natural functions; validated the schedule before emitting those routine bodies
- Fixed runtime-argument validation for entity/sprite resource handles and reset map/scroller IDs between compilations for deterministic outputs

- Added common `screen.setup`, `game.run` and joystick `scroll` helpers that expand to existing DSL instructions, preserving the legacy APIs
- Added natural typed-array `fill(value)` with compact descending 6502 loops; simplified hires, scrolling and Lights Out examples and added a common-helpers demo

- Fixed hires point color addressing at page boundaries: clear an already-propagated carry before adding the screen base, preventing missing bands and displaced colors in all shared drawing routines

- Added fixed Uint8Array/Uint16Array storage in natural mode, indexed reads/writes/updates and checked bounds, using native 6502 indexed addressing
- Added specialized function parameters for constant text, arrays and API objects, plus a complete natural Lights Out example
- Fixed duplicate memset labels when repeated screen clears occur in separate specialized routines

- Unified calculated arguments across hires shapes, text positioning/drawing, decimal counters, sprite colors/flags and scrolling; kept constant drawing paths and shared binary-to-decimal code
- Added `printNumber`, runtime sprite-handle appearance methods, an explicit `printAt` color, and a natural score/HUD example

- Added an opt-in `"use c64"` JavaScript frontend with natural conditions, integer expressions, loops and shared functions; legacy 1.0.1 sources keep their recording behavior
- Added explicit byte/word intrinsics, source diagnostics, short-circuit evaluation, and natural hires/sprite/scroll examples with executed-6502 regression coverage
- Added runtime coordinates to hires points/lines with endpoint bounds guards while preserving constant drawing paths

## 1.0.1 - 2026-09-19

- Fixed Platformer Mini's late horizontal row copies: prepare camera movement early, defer copying to the scroll-band end, and present up to eight logical sprites in fixed IRQ slots; added PAL row-fetch regression coverage across the complete map in both directions
- Replaced blocking SID effect delays with an on-demand 50 Hz PAL/NTSC IRQ sequencer, pooled effect tables, atomic retriggers and preserved map pointers; warn on synchronous legacy note/rest durations
- Fixed frame waits missing scanlines covered by IRQs, respected the scroll band with multiplexing, and published fine-scroll phases before coarse copies
- Fixed multiplexed sprite recycling across raster 255/256, replayed display lists on skipped NTSC logic ticks, committed Y after sprite attributes and guarded late channel writes
- Shared map address routines, used bounded row-address lookups for scrolling maps and omitted unused scroll directions
- Added execution tests for emitted 6502 code, including 8,128-cell maps, PAL/NTSC frame boundaries and SID effect lifetimes
- Fixed zero-page label fixups overwriting the following machine instruction and rejected labels outside zero page
- Made ROM-backed screen codes 0–63 automatic for every custom charset; `romCharacters` is no longer required in user assets
- Updated the asset studio to export only custom glyphs in JSON, JS, BIN and ASM while keeping the system area visible and protected in the editor
- Updated Snake with readable ROM-backed text and score, FIRE-to-start, and FIRE/SPACE restart with a complete map and score reset

## 1.0.0 - 2026-08-07

- Added the stable fixed game API: decimal score/lives counters, seeded deterministic RNG and compile-time bounded pools
- Updated Snake to validate the 1.0 score and seeded RNG APIs while still refusing food positions occupied by the snake
- Added release budgets for Snake, Breakout Mini, Maze Game and Platformer Mini with automated PRG, RAM and cycle regression checks
- Added a Windows/Linux Node 18/20/22 release matrix that builds every example and the multi-level D64
- Added an end-to-end `npm pack` gate that verifies public exports, installs the tarball in an empty project and runs the installed `npx c64js`
- Froze the 1.0 package metadata, TypeScript declarations, asset schemas and beginner/publication documentation

- Added standard 35-track D64 generation with BAM, chained directory sectors, PRG/USR entries and disk-full/name validation
- Added `--format d64`, automatic `.d64` detection, `--assets inline|disk`, `--device`, `--disk-name` and `--program-name`
- Added KERNAL disk loading through `SETNAM`/`SETLFS`/`LOAD`, deferred level transitions, IRQ restoration and a visible `DISK ERROR` state
- Externalized maps, charsets, tile/collision tables and sprite pixels with deterministic manifests and shared active RAM slots
- Added resident and per-level sprite loading plus `mapAsset.activate({ draw, sprites })`
- Added `examples/multilevel-d64.js`, three sample levels, D64 writer/compiler tests and detailed disk/block reports
- Store disk assets as load-address PRG data modules because the stock KERNAL `LOAD` routine rejects USR directory entries with `TYPE MISMATCH`
- Started the v1.0 game API with fixed `title`, `game`, `pause` and `gameOver` scenes plus deterministic between-frame transitions
- Added `mapAsset.activate()`/`isActive()`, one pending activation slot and embedded map reset routines in preparation for D64 levels
- Added `examples/game-scenes.js`, TypeScript declarations and `game-runtime`/map activation diagnostics
- Completed v0.11 optimization with `--opt size|balanced|speed`, balanced by default, and an `optimization-summary` build report
- Added conditional per-block RLE for maps and charsets, including decoder cost and startup-cycle estimates in the selection
- Added `--report` JSON output with comparative profiles, shared/omitted routine families, audio savings and multiplexer CPU estimates
- Compacted exact repeated periods in looping SID voice tables while preserving expanded/stored step diagnostics
- Added reusable `sid.instrument()` and nested/repeatable `sid.pattern()` definitions for the IRQ music player
- Added non-blocking bidirectional `sid.fadeSong()` with an on-demand IRQ runtime and preserved SID filter bits
- Pooled identical expanded music tables across voices and exposed pattern, instrument, fade and pooled-byte metrics in `sid-audio`
- Started v0.11 game audio with `reserveSfxVoice()`, deterministic music/effect voice ownership, `pauseSong()`/`resumeSong()` and looping songs
- Added an automatic logical 50 Hz SID clock for stable PAL/NTSC tempo plus `sid-audio`, `SID_VOICE_CONFLICT` and reserved-voice diagnostics
- Removed all three music tables for a reserved SID effect voice and added the playable `sid-game-audio.js` example
- Fixed advanced map collision tables incorrectly treating collision value `0` as solid, which prevented `platformer-mini` from moving
- Expanded `platformer-mini` to a 36 x 20 map viewport with a five-line fixed panel, cleared the BASIC screen on startup and shortened the multiplexer's lower-border raster wait
- Added compact relocated PRGs: code configured at `$4000` is copied by a small `$0810` loader instead of storing 14 KB of zero padding
- Completed v0.10.1 with persistent entity activation, spawn-based respawn, configurable viewport culling margins and entity/entity AABB collisions
- Added collision behavior tables with solid, one-way platform, danger, ladder, exit and passable tile semantics
- Added deterministic sprite-multiplexer budget reports and CLI warnings for raster overlap or insufficient reprogramming gaps
- Added `c64.program.start()` and custom-address PRG generation for games whose code must live outside VIC bank 0
- Added the two-zone `platformer-mini.js` example with X/Y camera follow, fixed panel, PAL/NTSC-safe scrolling, animation, SID, raster sharing and physical/virtual sprites
- Added drag-and-drop and direct X/Y editing for map objects in the asset studio, with bounds and occupied-cell validation
- Fixed repeated map-object creation in the asset studio by generating the next free id automatically (`objet1`, `objet2`, ...)
- Extended the offline asset studio with hires/multicolor sprite editing, frame management, named animations, hitbox/origin preview and `sprite-asset-v1` import/export
- Added studio selectors that attach a sprite asset and initial animation to map objects without manual JSON edits
- Added map-side sprite, spawn and hitbox overlays plus lossless full-project import/export for maps, charsets and sprite libraries
- Added the versioned `sprite-asset-v1` schema with reusable hires/multicolor frames, colors, origin, hitbox and named animations
- Added `c64.assets.loadSprite()`/`defineSprite()` and automatic map-object sprite resolution
- Added entity animation selection through object properties and `entity.play(name, direction)` without duplicating frame storage
- Added sprite-asset build diagnostics, shared multicolor validation and the external `v10-hero.sprite.json` example
- Made repeated `play()` calls keep the current animation position and initialized animation state deterministically
- Fixed the seven-pixel `$D016` phase mismatch between scrolling characters, projected sprites and tile hitboxes
- Replaced height-dependent map index loops with constant shift/add multiplication for faster collision probes
- Added paired top-to-bottom Screen/Color RAM coarse copies and automatic post-band frame synchronization
- Moved the fixed-panel split IRQ one raster before its badline to remove the unstable seam
- Stabilized bottom-panel text during vertical scrolling by normalizing the VIC-II `RC` and `VCBASE` state for all eight YSCROLL phases
- Added a background-colored blank transition row and automatic one-row Screen/Color RAM remapping for fixed-panel drawing
- Made map scrollers use VIC-only IRQ timing with the KERNAL CIA timer disabled to remove rare idle-frame flashes
- Added the four-pixel D011 projection phase and paired vertical coarse-copy loops
- Reject vertical directions that exceed their PAL beam deadline instead of emitting an unstable wrap
- Started v0.10.1 with stable map-object ids, optional sprite references and exact world-pixel coordinates
- Added `c64.map.object()`, `objects()`, `spawn()` and `spawnAll()` for map-linked logical sprites 0..15
- Added 16-bit entity world state and explicit camera projection with off-viewport hiding
- Added object id/sprite fields to the external studio and `examples/map-entity-spawn.js`
- Added hitbox-based `moveAndCollide()` with separate X/Y resolution and bounded pixel steps
- Added stable ground/ceiling/left/right contacts, entity velocity and `jump()`
- Tile collisions now treat every non-zero logical collision value as solid and follow dynamic map RAM changes
- Added a canonical 16-bit pixel camera synchronized with coarse and fine X/Y scrolling
- Added `camera.follow(entity)` with axis selection, dead zone, bounded catch-up speed and map clamping
- Added `camera.project(entity)` so physical and virtual sprites share the followed camera
- Added `map-camera-follow` build diagnostics and camera/entity regression coverage
- Replaced the old border-color guard with a short post-row `DEN` guard and an empty charset, preserving the configured background color
- Added exact fixed-panel sizes through `{ position: "bottom"|"top", rows }`, `{ bottom: n }` and `{ top: n }`
- Kept string `panel: "bottom"`/`"top"` behavior backward compatible
- Started v0.10 with bounded runtime map viewports through `c64.map.drawViewport()`
- Added 16-bit source-map viewport rendering with synchronized screen and Color RAM writes
- Added coarse-viewport CPU estimates against PAL and NTSC frame budgets in `assetReport`
- Added the joystick-controlled `examples/tilemap-scroll-x.js` camera foundation
- Added `c64.map.horizontalScroller()` with bounded bidirectional pixel scrolling through VIC-II `$D016`
- Added compact Screen RAM and Color RAM shifts plus incoming-column streaming on each 8-pixel wrap
- Added PAL/NTSC scroll-cycle estimates and rebuilt the joystick camera demo
- Extended the map scroller with `$D011` fine Y, `up()`/`down()` and optimized incoming-row streaming
- Added shared raster-band IRQs for fixed top or bottom score panels without replacing existing IRQ systems
- Replaced the scroll report with `map-scroll`, including X/Y wrap budgets and raster split lines
- Fixed vertical staircase motion by installing YSCROLL before the first badline when using a fixed bottom panel
- Reject vertical scrolling below a fixed top character panel until FLD/badline compensation is implemented
- Suppressed phase-dependent extra Screen-RAM row loads before fixed bottom panels
- Completed the v0.9 asset pipeline with 16-bit mutable-map indexes and up to 8,192 runtime cells
- Added runtime pixel/tile and character/tile coordinate conversion helpers
- Added hires and multicolor character modes with VIC-II color-register setup and validation
- Added typed object/spawn metadata to the v1 JSON schema and asset model
- Added detailed memory ranges, asset totals and hard overlap detection to `assetReport`
- Added the standalone offline character, metatile and map studio with JSON/BIN/JS/ASM/RLE exports
- Added playable 300-cell `snake.js` and multicolor `maze-game.js` examples with JSON sources
- Started v0.9 with a validated JSON format for charsets, metatiles, colors, collision values and static maps
- Added `c64.assets.loadMap()`/`defineMap()`, `c64.charset.use()` and `c64.map.draw()`
- Added runtime logical collision queries through `c64.map.tileAt().isSolid()` and `hasCollision()`
- Added automatic VIC-II charset bank setup, compiler asset reports and `examples/tilemap-static.js`
- Added mutable two-dimensional maps through `level.map(x, y)` with runtime `set`, `load`, `eq` and `ne`
- Added automatic single-metatile redraw, explicit full redraw and safe out-of-bounds map access
- Added the playable joystick-controlled `examples/tetris-mini.js` dynamic-map demo
- Added automatic 16-logical-sprite support through `c64.sprite.create(0..15)`
- Replaced the fixed two-zone renderer with a dynamic Y-sorted 16-to-8 VIC-II sprite multiplexer
- Added height-aware channel recycling for normal and vertically expanded sprites, with no unavailable middle zone
- Added logical pointer, color, multicolor, expansion and priority state for multiplexed sprites
- Kept software AABB collisions for all 16 sprites and rejected ambiguous VIC collision reads in multiplexed mode
- Added `examples/sprite-multiplex-16.js` plus multiplexer limits and regression tests
- Added balanced size optimization by default without changing user JavaScript
- Deduplicated identical sprite pixel constants while keeping explicit-address data independent
- Pooled repeated sprite synchronization, AABB comparison and non-blocking SID click code into generated subroutines
- Reduced `breakout-mini.prg` from 4,644 bytes to 3,335 bytes (about 28%) while adding 16-sprite logical state
- Added optimizer size and sharing regression tests
- Made `c64.sid.click()` non-blocking by removing its generated busy-wait delay
- Updated `breakout-mini.js` so missed balls leave through the bottom and restart
- Completed the v0.8 object-based sprite gameplay API with 9-bit runtime X positions
- Added signed velocity, bounds, stable clamp/bounce, activation and explicit VIC-II synchronization
- Added shared 64-byte frame assets, named animation sequences, looping and pause/resume
- Added configurable software AABB collisions and centralized VIC-II collision snapshots
- Added the playable `examples/breakout-mini.js` demo with paddle, ball, blocks, sound and score
- Migrated `game-loop-input.js` and `sprite-animate.js` to the v0.8 sprite API
- Added TypeScript declarations and eight-active-sprite budget coverage for the gameplay API
- Started the v0.7 gameplay foundation with auto-allocated runtime byte variables
- Added runtime byte assignment, arithmetic and comparisons
- Added `c64.control.if()` for generated 6502 branches
- Added frame-snapshot joystick input with held, pressed and released states
- Added `c64.game.frame()` with one deterministic update per video frame
- Added reserved runtime RAM overlap diagnostics
- Added `examples/game-loop-input.js` and automatic compilation coverage for every example
- Fixed standalone SID/sprite runtime IRQs so CIA hits no longer execute VIC raster work
- Completed the v0.7 runtime types with word and bool variables plus bit operations
- Added bounded repeat/while control flow and named generated routines
- Added runtime-indexed byte tables and configurable non-blocking keyboard actions
- Added `c64.game.init()` and counter-based `c64.game.every()` tasks
- Added PAL/NTSC detection and normalized 50 Hz logical updates

- Added `v0.2.0` comfort foundations
- Added `c64.data.*` declarations for bytes, words, PETSCII strings, and screen strings
- Added `c64.var.*` declarations plus `c64.varRef()`
- Added `c64.dataRef()`, `c64.copyDataTo()`, and `c64.memsetColor()`
- Added screen helpers including `printCentered`, `writeChar`, `fillRect`, `drawFrame`, and `clearLine`
- Added comfort-focused examples for frames, data, and variables
- Updated `examples/screen-fill.js` to use the new comfort API
- Started `v0.3.0` sprite foundations
- Added `c64.sprite.*` high-level helpers for enable/disable, position, colors, data, priority, multicolor, and expansion
- Reworked `examples/sprite-basic.js` to use the sprite API
- Started `v0.4.0` sprite animation foundations
- Added `c64.sprite.moveToX()`, `moveToY()`, `animateTo()`, `stop()`, `stopX()`, `stopY()`, and `installAnimator()`
- Added an internal raster IRQ sprite animator that updates X/Y over time and chains to the KERNAL IRQ
- Added `examples/sprite-animate.js`
- Added automated tests for sprite animator installation and error handling
- Added CLI `--sys` support for custom start addresses on data/bin/asm/lst outputs
- Added `compileJsToC64Outputs(source, options)` for in-memory DSL compilation and direct BASIC text export

## 0.1.0

- First npm-oriented release of `js-c64`
- Added a complete NMOS 6502 assembler core with labels, relocation and listing support
- Added Commodore 64 DSL helpers and raster IRQ support
- Added PRG, BIN, ASM, LST and BASIC DATA exporters
- Added CLI `c64js build` and `c64js init`
- Added `c64.irq.rasterLoop()` for READY-safe looping effects
- Added VICE-oriented showcase demos and a bulk demo build script
